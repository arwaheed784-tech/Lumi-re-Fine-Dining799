import { useState } from 'react';
import { ChevronLeft, CreditCard, Truck, Check, Shield, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useCartStore } from '@/store/cartStore';
import { useNavigationStore } from '@/store/navigationStore';
import type { CartItem } from '@/types';

export function Checkout() {
  const items = useCartStore((state) => state.items);
  const getTotalPrice = useCartStore((state) => state.getTotalPrice);
  const clearCart = useCartStore((state) => state.clearCart);
  const { setView } = useNavigationStore();

  const [step, setStep] = useState<'shipping' | 'payment' | 'success'>('shipping');
  const [isProcessing, setIsProcessing] = useState(false);

  const subtotal = getTotalPrice();
  const shipping = subtotal > 50 ? 0 : 9.99;
  const total = subtotal + shipping;

  if (items.length === 0 && step !== 'success') {
    setView('cart');
    return null;
  }

  const handlePlaceOrder = async () => {
    setIsProcessing(true);
    // Simulate order processing
    await new Promise((resolve) => setTimeout(resolve, 2000));
    setIsProcessing(false);
    clearCart();
    setStep('success');
  };

  if (step === 'success') {
    return (
      <main className="min-h-screen pt-24 pb-16 flex items-center justify-center bg-black">
        <div className="text-center max-w-md mx-auto px-4">
          <div className="w-24 h-24 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Check className="w-12 h-12 text-green-500" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">
            Order Placed Successfully!
          </h2>
          <p className="text-gray-400 mb-6">
            Thank you for your purchase. You will receive a confirmation email shortly.
          </p>
          <div className="bg-white/5 rounded-xl p-6 mb-6 text-left border border-white/10">
            <p className="text-sm text-gray-500 mb-1">Order Number</p>
            <p className="text-lg font-bold text-white">#LM-{Date.now().toString().slice(-8)}</p>
          </div>
          <Button
            size="lg"
            className="bg-white text-black hover:bg-gray-200"
            onClick={() => setView('home')}
          >
            Continue Shopping
          </Button>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen pt-24 pb-16 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <button
          onClick={() => setView('cart')}
          className="flex items-center text-gray-400 hover:text-white transition-colors mb-6"
        >
          <ChevronLeft className="w-4 h-4 mr-1" />
          Back to Cart
        </button>

        <h1 className="text-3xl font-bold text-white mb-8">Checkout</h1>

        {/* Progress */}
        <div className="flex items-center gap-4 mb-8">
          <div className={`flex items-center gap-2 ${step === 'shipping' ? 'text-white' : 'text-gray-600'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step === 'shipping' ? 'bg-white text-black' : 'bg-white/10 text-gray-400'}`}>
              <Truck className="w-4 h-4" />
            </div>
            <span className="font-medium">Shipping</span>
          </div>
          <div className="flex-1 h-px bg-white/20" />
          <div className={`flex items-center gap-2 ${step === 'payment' ? 'text-white' : 'text-gray-600'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step === 'payment' ? 'bg-white text-black' : 'bg-white/10 text-gray-400'}`}>
              <CreditCard className="w-4 h-4" />
            </div>
            <span className="font-medium">Payment</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Form */}
          <div className="lg:col-span-2">
            {step === 'shipping' ? (
              <div className="bg-white/5 rounded-xl p-6 border border-white/10">
                <h2 className="text-xl font-bold text-white mb-6">
                  Shipping Information
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName" className="text-gray-400">First Name</Label>
                    <Input id="firstName" placeholder="John" className="mt-1 bg-white/10 border-white/20 text-white placeholder:text-gray-500" />
                  </div>
                  <div>
                    <Label htmlFor="lastName" className="text-gray-400">Last Name</Label>
                    <Input id="lastName" placeholder="Doe" className="mt-1 bg-white/10 border-white/20 text-white placeholder:text-gray-500" />
                  </div>
                  <div className="sm:col-span-2">
                    <Label htmlFor="email" className="text-gray-400">Email</Label>
                    <Input id="email" type="email" placeholder="john@example.com" className="mt-1 bg-white/10 border-white/20 text-white placeholder:text-gray-500" />
                  </div>
                  <div className="sm:col-span-2">
                    <Label htmlFor="address" className="text-gray-400">Address</Label>
                    <Input id="address" placeholder="123 Main Street" className="mt-1 bg-white/10 border-white/20 text-white placeholder:text-gray-500" />
                  </div>
                  <div>
                    <Label htmlFor="city" className="text-gray-400">City</Label>
                    <Input id="city" placeholder="New York" className="mt-1 bg-white/10 border-white/20 text-white placeholder:text-gray-500" />
                  </div>
                  <div>
                    <Label htmlFor="state" className="text-gray-400">State</Label>
                    <Select>
                      <SelectTrigger className="mt-1 bg-white/10 border-white/20 text-white">
                        <SelectValue placeholder="Select state" />
                      </SelectTrigger>
                      <SelectContent className="bg-black border-white/20">
                        <SelectItem value="ny" className="text-white hover:bg-white/10">New York</SelectItem>
                        <SelectItem value="ca" className="text-white hover:bg-white/10">California</SelectItem>
                        <SelectItem value="tx" className="text-white hover:bg-white/10">Texas</SelectItem>
                        <SelectItem value="fl" className="text-white hover:bg-white/10">Florida</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="zip" className="text-gray-400">ZIP Code</Label>
                    <Input id="zip" placeholder="10001" className="mt-1 bg-white/10 border-white/20 text-white placeholder:text-gray-500" />
                  </div>
                  <div>
                    <Label htmlFor="phone" className="text-gray-400">Phone</Label>
                    <Input id="phone" placeholder="+1 (555) 123-4567" className="mt-1 bg-white/10 border-white/20 text-white placeholder:text-gray-500" />
                  </div>
                </div>

                <div className="mt-6">
                  <Label className="flex items-center gap-2 text-gray-400">
                    <Checkbox className="border-white/30 data-[state=checked]:bg-white data-[state=checked]:text-black" />
                    <span className="text-sm">
                      Save this address for future orders
                    </span>
                  </Label>
                </div>

                <Button
                  size="lg"
                  className="w-full mt-6 bg-white text-black hover:bg-gray-200"
                  onClick={() => setStep('payment')}
                >
                  Continue to Payment
                </Button>
              </div>
            ) : (
              <div className="bg-white/5 rounded-xl p-6 border border-white/10">
                <h2 className="text-xl font-bold text-white mb-6">
                  Payment Information
                </h2>

                {/* Payment Methods */}
                <div className="grid grid-cols-3 gap-4 mb-6">
                  {['Credit Card', 'PayPal', 'Apple Pay'].map((method) => (
                    <button
                      key={method}
                      className={`p-4 border-2 rounded-lg text-center transition-colors ${
                        method === 'Credit Card'
                          ? 'border-white bg-white/10'
                          : 'border-white/20 hover:border-white/40'
                      }`}
                    >
                      <CreditCard className="w-6 h-6 mx-auto mb-2 text-gray-400" />
                      <span className="text-sm font-medium text-white">{method}</span>
                    </button>
                  ))}
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="cardNumber" className="text-gray-400">Card Number</Label>
                    <div className="relative">
                      <Input
                        id="cardNumber"
                        placeholder="1234 5678 9012 3456"
                        className="mt-1 pl-10 bg-white/10 border-white/20 text-white placeholder:text-gray-500"
                      />
                      <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="cardHolder" className="text-gray-400">Card Holder Name</Label>
                    <Input id="cardHolder" placeholder="John Doe" className="mt-1 bg-white/10 border-white/20 text-white placeholder:text-gray-500" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="expiry" className="text-gray-400">Expiry Date</Label>
                      <Input id="expiry" placeholder="MM/YY" className="mt-1 bg-white/10 border-white/20 text-white placeholder:text-gray-500" />
                    </div>
                    <div>
                      <Label htmlFor="cvv" className="text-gray-400">CVV</Label>
                      <div className="relative">
                        <Input id="cvv" placeholder="123" className="mt-1 bg-white/10 border-white/20 text-white placeholder:text-gray-500" type="password" maxLength={4} />
                        <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6">
                  <Label className="flex items-center gap-2 text-gray-400">
                    <Checkbox className="border-white/30 data-[state=checked]:bg-white data-[state=checked]:text-black" />
                    <span className="text-sm">
                      Save card for future purchases
                    </span>
                  </Label>
                </div>

                <div className="flex gap-4 mt-6">
                  <Button
                    variant="outline"
                    className="flex-1 border-white/20 text-white hover:bg-white/10"
                    onClick={() => setStep('shipping')}
                  >
                    Back
                  </Button>
                  <Button
                    size="lg"
                    className="flex-1 bg-white text-black hover:bg-gray-200"
                    onClick={handlePlaceOrder}
                    disabled={isProcessing}
                  >
                    {isProcessing ? (
                      <span className="flex items-center">
                        <span className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin mr-2" />
                        Processing...
                      </span>
                    ) : (
                      <span className="flex items-center">
                        <Lock className="w-4 h-4 mr-2" />
                        Place Order
                      </span>
                    )}
                  </Button>
                </div>

                <div className="mt-4 flex items-center justify-center gap-2 text-sm text-gray-500">
                  <Shield className="w-4 h-4" />
                  Secure checkout powered by Stripe
                </div>
              </div>
            )}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white/5 rounded-xl p-6 border border-white/10 sticky top-24">
              <h2 className="text-xl font-bold text-white mb-6">
                Order Summary
              </h2>

              {/* Items */}
              <div className="space-y-4 mb-6 max-h-64 overflow-auto">
                {items.map((item: CartItem) => (
                  <div key={item.id} className="flex gap-4">
                    <div className="w-16 h-16 bg-white/5 rounded-lg overflow-hidden flex-shrink-0">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-medium text-white line-clamp-1">
                        {item.name}
                      </h4>
                      <p className="text-sm text-gray-500">
                        Qty: {item.quantity}
                      </p>
                      <p className="text-sm font-medium text-white">
                        ${(item.price * item.quantity).toFixed(2)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Totals */}
              <div className="space-y-3 border-t border-white/10 pt-4">
                <div className="flex justify-between text-gray-400">
                  <span>Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Shipping</span>
                  <span>{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span>
                </div>
                <div className="flex justify-between text-xl font-bold text-white border-t border-white/10 pt-3">
                  <span>Total</span>
                  <span>${total.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
