import { useState } from 'react';
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight, Truck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useCartStore } from '@/store/cartStore';
import { useNavigationStore } from '@/store/navigationStore';
import type { CartItem } from '@/types';

export function Cart() {
  const items = useCartStore((state) => state.items);
  const removeFromCart = useCartStore((state) => state.removeFromCart);
  const updateQuantity = useCartStore((state) => state.updateQuantity);
  const getTotalPrice = useCartStore((state) => state.getTotalPrice);
  const { setView, setSelectedProduct } = useNavigationStore();
  const [promoCode, setPromoCode] = useState('');

  const subtotal = getTotalPrice();
  const shipping = subtotal > 50 ? 0 : 9.99;
  const discount = promoCode === 'SAVE10' ? subtotal * 0.1 : 0;
  const total = subtotal + shipping - discount;

  if (items.length === 0) {
    return (
      <main className="min-h-screen pt-24 pb-16 flex items-center justify-center bg-black">
        <div className="text-center max-w-md mx-auto px-4">
          <div className="w-24 h-24 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <ShoppingBag className="w-12 h-12 text-gray-500" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">
            Your cart is empty
          </h2>
          <p className="text-gray-400 mb-6">
            Looks like you haven't added anything to your cart yet.
          </p>
          <Button
            size="lg"
            className="bg-white text-black hover:bg-gray-200"
            onClick={() => setView('products')}
          >
            Start Shopping
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen pt-24 pb-16 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-white mb-8">Shopping Cart</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {items.map((item: CartItem) => (
              <div
                key={item.id}
                className="bg-white/5 rounded-xl p-4 sm:p-6 border border-white/10 flex flex-col sm:flex-row gap-4"
              >
                {/* Image */}
                <div
                  onClick={() => {
                    setSelectedProduct(item.id);
                    setView('product-detail');
                  }}
                  className="w-full sm:w-32 h-32 bg-white/5 rounded-lg overflow-hidden flex-shrink-0 cursor-pointer"
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Details */}
                <div className="flex-1 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex-1">
                    <h3
                      className="font-semibold text-white hover:text-gray-300 cursor-pointer transition-colors"
                      onClick={() => {
                        setSelectedProduct(item.id);
                        setView('product-detail');
                      }}
                    >
                      {item.name}
                    </h3>
                    <p className="text-sm text-gray-500 mt-1">{item.category}</p>
                    <p className="text-lg font-bold text-white mt-2">
                      ${item.price.toFixed(2)}
                    </p>
                  </div>

                  {/* Quantity & Actions */}
                  <div className="flex items-center gap-4">
                    <div className="flex items-center border border-white/20 rounded-lg">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="p-2 hover:bg-white/10 transition-colors text-white"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="w-10 text-center font-medium text-white">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="p-2 hover:bg-white/10 transition-colors text-white"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="p-2 text-gray-500 hover:text-red-400 transition-colors"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}

            {/* Continue Shopping */}
            <Button
              variant="outline"
              className="w-full sm:w-auto border-white/20 text-white hover:bg-white/10"
              onClick={() => setView('products')}
            >
              Continue Shopping
            </Button>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white/5 rounded-xl p-6 border border-white/10 sticky top-24">
              <h2 className="text-xl font-bold text-white mb-6">
                Order Summary
              </h2>

              {/* Promo Code */}
              <div className="mb-6">
                <label className="text-sm font-medium text-gray-400 mb-2 block">
                  Promo Code
                </label>
                <div className="flex gap-2">
                  <Input
                    type="text"
                    placeholder="Enter code"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder:text-gray-500"
                  />
                  <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">Apply</Button>
                </div>
                {promoCode === 'SAVE10' && (
                  <p className="text-sm text-green-400 mt-2">
                    10% discount applied!
                  </p>
                )}
              </div>

              {/* Summary */}
              <div className="space-y-3 border-t border-white/10 pt-4">
                <div className="flex justify-between text-gray-400">
                  <span>Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Shipping</span>
                  <span>{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-green-400">
                    <span>Discount</span>
                    <span>-${discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-xl font-bold text-white border-t border-white/10 pt-3">
                  <span>Total</span>
                  <span>${total.toFixed(2)}</span>
                </div>
              </div>

              {/* Checkout Button */}
              <Button
                size="lg"
                className="w-full mt-6 bg-white text-black hover:bg-gray-200"
                onClick={() => setView('checkout')}
              >
                Proceed to Checkout
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>

              {/* Free Shipping Notice */}
              {subtotal < 50 && (
                <div className="mt-4 p-3 bg-white/5 rounded-lg flex items-center gap-3 border border-white/10">
                  <Truck className="w-5 h-5 text-white" />
                  <p className="text-sm text-gray-400">
                    Add ${(50 - subtotal).toFixed(2)} more for free shipping!
                  </p>
                </div>
              )}

              {/* Payment Methods */}
              <div className="mt-6 text-center">
                <p className="text-sm text-gray-500 mb-3">We accept</p>
                <div className="flex justify-center gap-2">
                  {['Visa', 'MC', 'Amex', 'PayPal'].map((method) => (
                    <div
                      key={method}
                      className="w-12 h-8 bg-white/10 rounded flex items-center justify-center text-xs font-medium text-gray-400"
                    >
                      {method}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
