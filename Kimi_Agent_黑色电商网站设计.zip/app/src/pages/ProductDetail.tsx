import { useState } from 'react';
import { Star, ShoppingCart, Heart, Share2, Truck, Shield, RotateCcw, ChevronLeft, Minus, Plus, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { getProductById, getRelatedProducts, getReviewsByProductId } from '@/data/products';
import { useCartStore } from '@/store/cartStore';
import { useNavigationStore } from '@/store/navigationStore';

export function ProductDetail() {
  const { selectedProductId, setView, navigateToProduct } = useNavigationStore();
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  const [isAdded, setIsAdded] = useState(false);

  const product = selectedProductId ? getProductById(selectedProductId) : null;
  const addToCart = useCartStore((state) => state.addToCart);
  const reviews = selectedProductId ? getReviewsByProductId(selectedProductId) : [];
  const relatedProducts = selectedProductId ? getRelatedProducts(selectedProductId) : [];

  if (!product) {
    return (
      <main className="min-h-screen pt-24 pb-16 flex items-center justify-center bg-black">
        <div className="text-center">
          <p className="text-gray-400 text-lg">Product not found</p>
          <Button className="mt-4 bg-white text-black hover:bg-gray-200" onClick={() => setView('products')}>
            Back to Products
          </Button>
        </div>
      </main>
    );
  }

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(product);
    }
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  const images = [product.image, product.image, product.image];

  return (
    <main className="min-h-screen pt-24 pb-16 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <button
          onClick={() => setView('products')}
          className="flex items-center text-gray-400 hover:text-white transition-colors mb-6"
        >
          <ChevronLeft className="w-4 h-4 mr-1" />
          Back to Products
        </button>

        {/* Product Info */}
        <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 p-6 lg:p-10">
            {/* Image Gallery */}
            <div className="space-y-4">
              <div className="aspect-square bg-white/5 rounded-xl overflow-hidden">
                <img
                  src={images[selectedImage]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex gap-3">
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={`w-20 h-20 rounded-lg overflow-hidden border-2 transition-colors ${
                      selectedImage === idx ? 'border-white' : 'border-transparent'
                    }`}
                  >
                    <img
                      src={img}
                      alt={`${product.name} ${idx + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Product Details */}
            <div className="space-y-6">
              {/* Badges */}
              <div className="flex gap-2">
                {product.isNew && <Badge className="bg-white text-black">New Arrival</Badge>}
                {product.isSale && <Badge className="bg-red-500 text-white">Sale</Badge>}
                {!product.inStock && <Badge variant="secondary" className="bg-white/20 text-white">Out of Stock</Badge>}
              </div>

              {/* Title & Rating */}
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold text-white mb-3">
                  {product.name}
                </h1>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-5 h-5 ${
                          i < Math.floor(product.rating)
                            ? 'fill-star text-star'
                            : 'text-gray-600'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-gray-400">
                    {product.rating} ({product.reviewCount} reviews)
                  </span>
                </div>
              </div>

              {/* Price */}
              <div className="flex items-center gap-4">
                <span className="text-3xl sm:text-4xl font-bold text-white">
                  ${product.price.toFixed(2)}
                </span>
                {product.originalPrice && (
                  <>
                    <span className="text-xl text-gray-500 line-through">
                      ${product.originalPrice.toFixed(2)}
                    </span>
                    <Badge className="bg-red-500/20 text-red-400">
                      Save ${(product.originalPrice - product.price).toFixed(2)}
                    </Badge>
                  </>
                )}
              </div>

              {/* Description */}
              <p className="text-gray-400 leading-relaxed">{product.description}</p>

              {/* Features */}
              {product.features && (
                <div className="space-y-2">
                  <h3 className="font-semibold text-white">Key Features:</h3>
                  <ul className="grid grid-cols-2 gap-2">
                    {product.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-sm text-gray-400">
                        <Check className="w-4 h-4 text-green-500" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Quantity & Add to Cart */}
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <div className="flex items-center border border-white/20 rounded-lg">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-3 hover:bg-white/10 transition-colors text-white"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-12 text-center font-medium text-white">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-3 hover:bg-white/10 transition-colors text-white"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                <Button
                  size="lg"
                  className="flex-1 bg-white text-black hover:bg-gray-200"
                  onClick={handleAddToCart}
                  disabled={!product.inStock || isAdded}
                >
                  {isAdded ? (
                    <>
                      <Check className="w-5 h-5 mr-2" />
                      Added to Cart
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="w-5 h-5 mr-2" />
                      Add to Cart
                    </>
                  )}
                </Button>
                <Button size="lg" variant="outline" className="px-4 border-white/20 text-white hover:bg-white/10">
                  <Heart className="w-5 h-5" />
                </Button>
                <Button size="lg" variant="outline" className="px-4 border-white/20 text-white hover:bg-white/10">
                  <Share2 className="w-5 h-5" />
                </Button>
              </div>

              {/* Trust Badges */}
              <div className="grid grid-cols-3 gap-4 pt-6 border-t border-white/10">
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <Truck className="w-5 h-5 text-white" />
                  Free Shipping
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <Shield className="w-5 h-5 text-white" />
                  Secure Payment
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <RotateCcw className="w-5 h-5 text-white" />
                  Easy Returns
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-10">
          <Tabs defaultValue="description" className="bg-white/5 rounded-2xl border border-white/10">
            <TabsList className="w-full justify-start border-b border-white/10 rounded-none px-6 pt-4 bg-transparent">
              <TabsTrigger value="description" className="text-gray-400 data-[state=active]:text-white data-[state=active]:border-b-white">Description</TabsTrigger>
              <TabsTrigger value="reviews" className="text-gray-400 data-[state=active]:text-white data-[state=active]:border-b-white">Reviews ({reviews.length})</TabsTrigger>
              <TabsTrigger value="shipping" className="text-gray-400 data-[state=active]:text-white data-[state=active]:border-b-white">Shipping & Returns</TabsTrigger>
            </TabsList>
            <TabsContent value="description" className="p-6">
              <div className="max-w-3xl">
                <h3 className="text-lg font-semibold text-white mb-4">Product Description</h3>
                <p className="text-gray-400 leading-relaxed">{product.description}</p>
                {product.features && (
                  <div className="mt-6">
                    <h4 className="font-semibold text-white mb-3">Features:</h4>
                    <ul className="space-y-2">
                      {product.features.map((feature, idx) => (
                        <li key={idx} className="flex items-center gap-2 text-gray-400">
                          <Check className="w-4 h-4 text-green-500" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </TabsContent>
            <TabsContent value="reviews" className="p-6">
              <div className="max-w-3xl">
                <h3 className="text-lg font-semibold text-white mb-6">Customer Reviews</h3>
                {reviews.length === 0 ? (
                  <p className="text-gray-400">No reviews yet. Be the first to review!</p>
                ) : (
                  <div className="space-y-6">
                    {reviews.map((review) => (
                      <div key={review.id} className="border-b border-white/10 pb-6">
                        <div className="flex items-start gap-4">
                          <img
                            src={review.avatar}
                            alt={review.author}
                            className="w-12 h-12 rounded-full object-cover"
                          />
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-semibold text-white">{review.author}</span>
                              <span className="text-gray-500 text-sm">{review.date}</span>
                            </div>
                            <div className="flex gap-1 mb-2">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`w-4 h-4 ${
                                    i < review.rating
                                      ? 'fill-star text-star'
                                      : 'text-gray-600'
                                  }`}
                                />
                              ))}
                            </div>
                            <p className="text-gray-400">{review.comment}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>
            <TabsContent value="shipping" className="p-6">
              <div className="max-w-3xl">
                <h3 className="text-lg font-semibold text-white mb-4">Shipping Information</h3>
                <ul className="space-y-3 text-gray-400 mb-8">
                  <li>• Free standard shipping on orders over $50</li>
                  <li>• Standard delivery: 5-7 business days</li>
                  <li>• Express delivery: 2-3 business days (additional fee)</li>
                  <li>• International shipping available</li>
                </ul>
                <h3 className="text-lg font-semibold text-white mb-4">Return Policy</h3>
                <ul className="space-y-3 text-gray-400">
                  <li>• 30-day return window</li>
                  <li>• Items must be in original condition</li>
                  <li>• Free returns on defective items</li>
                  <li>• Refunds processed within 5-7 business days</li>
                </ul>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="mt-10">
            <h2 className="text-2xl font-bold text-white mb-6">Related Products</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((related) => (
                <div
                  key={related.id}
                  onClick={() => navigateToProduct(related.id)}
                  className="bg-white/5 rounded-xl overflow-hidden border border-white/10 hover:border-white/30 transition-all duration-300 cursor-pointer group"
                >
                  <div className="aspect-square bg-white/5 overflow-hidden">
                    <img
                      src={related.image}
                      alt={related.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                  <div className="p-4">
                    <h3 className="font-medium text-white line-clamp-1 group-hover:text-gray-300 transition-colors">
                      {related.name}
                    </h3>
                    <p className="text-lg font-bold text-white mt-1">
                      ${related.price.toFixed(2)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
