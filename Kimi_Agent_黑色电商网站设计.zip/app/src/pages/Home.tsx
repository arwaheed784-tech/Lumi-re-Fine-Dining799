import { Hero } from '@/sections/Hero';
import { Features } from '@/sections/Features';
import { FeaturedProducts } from '@/sections/FeaturedProducts';
import { Categories } from '@/sections/Categories';
import { BestSellers } from '@/sections/BestSellers';
import { Testimonials } from '@/sections/Testimonials';
import { Newsletter } from '@/sections/Newsletter';

export function Home() {
  return (
    <main className="min-h-screen">
      <Hero />
      <Features />
      <FeaturedProducts />
      <Categories />
      <BestSellers />
      <Testimonials />
      <Newsletter />
    </main>
  );
}
