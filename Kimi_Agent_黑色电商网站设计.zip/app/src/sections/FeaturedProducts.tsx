import { useEffect, useRef, useState } from 'react';
import { Heart, Eye, ShoppingCart, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { products } from '@/data/products';
import { useCartStore } from '@/store/cartStore';
import { useNavigationStore } from '@/store/navigationStore';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import type { Product } from '@/types';

const featuredProducts = products.slice(0, 8);

export function FeaturedProducts() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const addToCart = useCartStore((state) => state.addToCart);
  const { navigateToProduct, setView } = useNavigationStore();

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleAddToCart = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product);
  };

  return (
    <section id="featured" ref={sectionRef} className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2
            className={`text-3xl sm:text-4xl font-bold text-white mb-4 ${
              isVisible ? 'animate-fade-in-up' : 'opacity-0'
            }`}
          >
            Featured Products
          </h2>
          <p
            className={`text-gray-400 max-w-2xl mx-auto ${
              isVisible ? 'animate-fade-in-up stagger-1' : 'opacity-0'
            }`}
          >
            Handpicked selection of our best-selling items, curated just for you
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product, index) => (
            <div
              key={product.id}
              onClick={() => navigateToProduct(product.id)}
              className={`group cursor-pointer ${
                isVisible ? 'animate-fade-in-up' : 'opacity-0'
              }`}
              style={{ animationDelay: `${(index + 2) * 80}ms` }}
            >
              <div className="product-card bg-white/5 rounded-xl overflow-hidden border border-white/10 hover:border-white/30">
                {/* Image Container */}
                <div className="relative aspect-square overflow-hidden bg-white/5">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover img-zoom"
                  />

                  {/* Badges */}
                  <div className="absolute top-3 left-3 flex flex-col gap-2">
                    {product.isNew && (
                      <Badge className="bg-white text-black">New</Badge>
                    )}
                    {product.isSale && (
                      <Badge className="bg-red-500 text-white">Sale</Badge>
                    )}
                  </div>

                  {/* Quick Actions */}
                  <div className="absolute inset-x-0 bottom-0 p-3 flex justify-center gap-2 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setQuickViewProduct(product);
                      }}
                      className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-gray-200 transition-colors"
                    >
                      <Eye className="w-4 h-4 text-black" />
                    </button>
                    <button
                      onClick={(e) => handleAddToCart(product, e)}
                      className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-gray-200 transition-colors"
                    >
                      <ShoppingCart className="w-4 h-4 text-black" />
                    </button>
                    <button
                      onClick={(e) => e.stopPropagation()}
                      className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-gray-200 transition-colors"
                    >
                      <Heart className="w-4 h-4 text-black" />
                    </button>
                  </div>
                </div>

                {/* Content */}
                <div className="p-4">
                  {/* Rating */}
                  <div className="flex items-center gap-1 mb-2">
                    <Star className="w-4 h-4 fill-star text-star" />
                    <span className="text-sm font-medium text-white">{product.rating}</span>
                    <span className="text-sm text-gray-500">
                      ({product.reviewCount})
                    </span>
                  </div>

                  {/* Name */}
                  <h3 className="font-medium text-white mb-2 line-clamp-1 group-hover:text-gray-300 transition-colors">
                    {product.name}
                  </h3>

                  {/* Price */}
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-bold text-white">
                      ${product.price.toFixed(2)}
                    </span>
                    {product.originalPrice && (
                      <span className="text-sm text-gray-500 line-through">
                        ${product.originalPrice.toFixed(2)}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View All Button */}
        <div
          className={`text-center mt-12 ${
            isVisible ? 'animate-fade-in-up stagger-8' : 'opacity-0'
          }`}
        >
          <Button
            variant="outline"
            size="lg"
            className="px-8 border-white/30 text-white hover:bg-white/10"
            onClick={() => setView('products')}
          >
            View All Products
          </Button>
        </div>
      </div>

      {/* Quick View Dialog */}
      <Dialog open={!!quickViewProduct} onOpenChange={() => setQuickViewProduct(null)}>
        <DialogContent className="max-w-3xl bg-black border-white/20">
          {quickViewProduct && (
            <>
              <DialogHeader>
                <DialogTitle className="text-white">Quick View</DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="aspect-square bg-white/5 rounded-lg overflow-hidden">
                  <img
                    src={quickViewProduct.image}
                    alt={quickViewProduct.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="space-y-4">
                  <h3 className="text-2xl font-bold text-white">{quickViewProduct.name}</h3>
                  <div className="flex items-center gap-2">
                    <Star className="w-5 h-5 fill-star text-star" />
                    <span className="font-medium text-white">{quickViewProduct.rating}</span>
                    <span className="text-gray-400">
                      ({quickViewProduct.reviewCount} reviews)
                    </span>
                  </div>
                  <p className="text-gray-400">{quickViewProduct.description}</p>
                  <div className="flex items-center gap-3">
                    <span className="text-3xl font-bold text-white">
                      ${quickViewProduct.price.toFixed(2)}
                    </span>
                    {quickViewProduct.originalPrice && (
                      <span className="text-xl text-gray-500 line-through">
                        ${quickViewProduct.originalPrice.toFixed(2)}
                      </span>
                    )}
                  </div>
                  <div className="flex gap-3">
                    <Button
                      className="flex-1 bg-white text-black hover:bg-gray-200"
                      onClick={() => {
                        addToCart(quickViewProduct);
                        setQuickViewProduct(null);
                      }}
                    >
                      <ShoppingCart className="w-4 h-4 mr-2" />
                      Add to Cart
                    </Button>
                    <Button
                      variant="outline"
                      className="border-white/30 text-white hover:bg-white/10"
                      onClick={() => {
                        navigateToProduct(quickViewProduct.id);
                        setQuickViewProduct(null);
                      }}
                    >
                      View Details
                    </Button>
                  </div>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
