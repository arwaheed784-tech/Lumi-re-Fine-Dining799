import { useEffect, useRef, useState } from 'react';
import { Smartphone, ShoppingBag, Home, Dumbbell, Sparkles, BookOpen, ArrowRight } from 'lucide-react';
import { categories } from '@/data/products';
import { useNavigationStore } from '@/store/navigationStore';

const iconMap: Record<string, React.ElementType> = {
  Smartphone,
  ShoppingBag,
  Home,
  Dumbbell,
  Sparkles,
  BookOpen,
};

export function Categories() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const { setView } = useNavigationStore();

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleCategoryClick = () => {
    setView('products');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <section id="categories" ref={sectionRef} className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2
            className={`text-3xl sm:text-4xl font-bold text-white mb-4 ${
              isVisible ? 'animate-fade-in-up' : 'opacity-0'
            }`}
          >
            Shop by Category
          </h2>
          <p
            className={`text-gray-400 max-w-2xl mx-auto ${
              isVisible ? 'animate-fade-in-up stagger-1' : 'opacity-0'
            }`}
          >
            Browse our wide range of categories and find exactly what you need
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 lg:gap-6">
          {categories.map((category, index) => {
            const Icon = iconMap[category.icon] || ShoppingBag;
            return (
              <button
                key={category.id}
                onClick={handleCategoryClick}
                className={`group relative bg-white/5 rounded-xl p-6 text-center border border-white/10 hover:border-white/30 transition-all duration-300 hover:-translate-y-1 ${
                  isVisible ? 'animate-fade-in-up' : 'opacity-0'
                }`}
                style={{ animationDelay: `${(index + 2) * 100}ms` }}
              >
                {/* Icon */}
                <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-white/10 flex items-center justify-center group-hover:bg-white group-hover:text-black transition-all duration-300">
                  <Icon className="w-7 h-7 text-white group-hover:text-black transition-colors" />
                </div>

                {/* Content */}
                <h3 className="font-semibold text-white mb-1 group-hover:text-gray-300 transition-colors">
                  {category.name}
                </h3>
                <p className="text-sm text-gray-500">
                  {category.productCount} products
                </p>

                {/* Arrow */}
                <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                  <ArrowRight className="w-4 h-4 text-white" />
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
