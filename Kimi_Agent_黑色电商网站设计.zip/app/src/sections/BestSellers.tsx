import { useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Star, ShoppingCart } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { products } from '@/data/products';
import { useCartStore } from '@/store/cartStore';
import { useNavigationStore } from '@/store/navigationStore';

const bestSellers = products
  .sort((a, b) => b.reviewCount - a.reviewCount)
  .slice(0, 6);

export function BestSellers() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const sliderRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const addToCart = useCartStore((state) => state.addToCart);
  const { navigateToProduct } = useNavigationStore();

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const checkScroll = () => {
    if (sliderRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = sliderRef.current;
      setCanScrollLeft(scrollLeft > 0);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
    }
  };

  useEffect(() => {
    const slider = sliderRef.current;
    if (slider) {
      slider.addEventListener('scroll', checkScroll, { passive: true });
      checkScroll();
      return () => slider.removeEventListener('scroll', checkScroll);
    }
  }, []);

  const scroll = (direction: 'left' | 'right') => {
    if (sliderRef.current) {
      const scrollAmount = 320;
      sliderRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  return (
    <section ref={sectionRef} className="py-20 bg-black border-y border-white/10 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between mb-12">
          <div>
            <h2
              className={`text-3xl sm:text-4xl font-bold text-white mb-4 ${
                isVisible ? 'animate-fade-in-up' : 'opacity-0'
              }`}
            >
              Best Selling Products
            </h2>
            <p
              className={`text-gray-400 max-w-xl ${
                isVisible ? 'animate-fade-in-up stagger-1' : 'opacity-0'
              }`}
            >
              Most loved by our customers - these items are flying off the shelves!
            </p>
          </div>

          {/* Navigation Arrows */}
          <div
            className={`flex gap-2 mt-6 sm:mt-0 ${
              isVisible ? 'animate-fade-in-up stagger-2' : 'opacity-0'
            }`}
          >
            <button
              onClick={() => scroll('left')}
              disabled={!canScrollLeft}
              className={`w-12 h-12 rounded-full border-2 flex items-center justify-center transition-all duration-300 ${
                canScrollLeft
                  ? 'border-white/30 hover:border-white hover:bg-white hover:text-black text-white'
                  : 'border-white/10 text-white/30 cursor-not-allowed'
              }`}
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => scroll('right')}
              disabled={!canScrollRight}
              className={`w-12 h-12 rounded-full border-2 flex items-center justify-center transition-all duration-300 ${
                canScrollRight
                  ? 'border-white/30 hover:border-white hover:bg-white hover:text-black text-white'
                  : 'border-white/10 text-white/30 cursor-not-allowed'
              }`}
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Products Slider */}
        <div
          ref={sliderRef}
          className="flex gap-6 overflow-x-auto scrollbar-hide pb-4 -mx-4 px-4"
          style={{ scrollSnapType: 'x mandatory' }}
        >
          {bestSellers.map((product, index) => (
            <div
              key={product.id}
              onClick={() => navigateToProduct(product.id)}
              className={`flex-shrink-0 w-72 cursor-pointer group ${
                isVisible ? 'animate-fade-in-up' : 'opacity-0'
              }`}
              style={{
                animationDelay: `${(index + 3) * 100}ms`,
                scrollSnapAlign: 'start',
              }}
            >
              <div className="bg-white/5 rounded-xl overflow-hidden border border-white/10 hover:border-white/30 shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                {/* Image */}
                <div className="relative aspect-square overflow-hidden bg-white/5">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />

                  {/* Badges */}
                  <div className="absolute top-3 left-3 flex flex-col gap-2">
                    {index < 3 && (
                      <Badge className="bg-white text-black">
                        #{index + 1} Best Seller
                      </Badge>
                    )}
                  </div>

                  {/* Add to Cart Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      addToCart(product);
                    }}
                    className="absolute bottom-3 right-3 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-gray-200 translate-y-2 group-hover:translate-y-0"
                  >
                    <ShoppingCart className="w-4 h-4 text-black" />
                  </button>
                </div>

                {/* Content */}
                <div className="p-4">
                  {/* Rating */}
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.floor(product.rating)
                              ? 'fill-star text-star'
                              : 'text-gray-600'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-500">
                      ({product.reviewCount})
                    </span>
                  </div>

                  {/* Name */}
                  <h3 className="font-medium text-white mb-2 line-clamp-1 group-hover:text-gray-300 transition-colors">
                    {product.name}
                  </h3>

                  {/* Price */}
                  <div className="flex items-center justify-between">
                    <span className="text-xl font-bold text-white">
                      ${product.price.toFixed(2)}
                    </span>
                    {product.originalPrice && (
                      <span className="text-sm text-gray-500 line-through">
                        ${product.originalPrice.toFixed(2)}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
