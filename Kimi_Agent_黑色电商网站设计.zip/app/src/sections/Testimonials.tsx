import { useEffect, useRef, useState } from 'react';
import { Star, Quote } from 'lucide-react';
import { testimonials } from '@/data/products';

export function Testimonials() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2
            className={`text-3xl sm:text-4xl font-bold text-white mb-4 ${
              isVisible ? 'animate-fade-in-up' : 'opacity-0'
            }`}
          >
            What Our Customers Say
          </h2>
          <p
            className={`text-gray-400 max-w-2xl mx-auto ${
              isVisible ? 'animate-fade-in-up stagger-1' : 'opacity-0'
            }`}
          >
            Real feedback from real customers who love our products
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={testimonial.id}
              className={`relative bg-white/5 rounded-2xl p-8 border border-white/10 hover:border-white/30 transition-all duration-300 ${
                isVisible ? 'animate-fade-in-up' : 'opacity-0'
              }`}
              style={{
                animationDelay: `${(index + 2) * 150}ms`,
                transform: index === 1 ? 'translateY(-20px)' : 'none',
              }}
            >
              {/* Quote Icon */}
              <div className="absolute -top-4 left-8">
                <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                  <Quote className="w-5 h-5 text-black" />
                </div>
              </div>

              {/* Rating */}
              <div className="flex gap-1 mb-4 mt-2">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-5 h-5 fill-star text-star"
                  />
                ))}
              </div>

              {/* Quote */}
              <p className="text-gray-300 mb-6 leading-relaxed">
                "{testimonial.quote}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-4">
                <img
                  src={testimonial.avatar}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <h4 className="font-semibold text-white">
                    {testimonial.name}
                  </h4>
                  <p className="text-sm text-gray-500">{testimonial.role}</p>
                </div>
              </div>

              {/* Decorative Element */}
              <div className="absolute bottom-0 right-0 w-24 h-24 bg-white/5 rounded-tl-full rounded-br-2xl -z-10" />
            </div>
          ))}
        </div>

        {/* Trust Badges */}
        <div
          className={`mt-16 flex flex-wrap justify-center items-center gap-8 ${
            isVisible ? 'animate-fade-in-up stagger-5' : 'opacity-0'
          }`}
        >
          <div className="text-center">
            <p className="text-4xl font-bold text-white">50K+</p>
            <p className="text-sm text-gray-500">Happy Customers</p>
          </div>
          <div className="w-px h-12 bg-white/20 hidden sm:block" />
          <div className="text-center">
            <p className="text-4xl font-bold text-white">4.9</p>
            <p className="text-sm text-gray-500">Average Rating</p>
          </div>
          <div className="w-px h-12 bg-white/20 hidden sm:block" />
          <div className="text-center">
            <p className="text-4xl font-bold text-white">98%</p>
            <p className="text-sm text-gray-500">Would Recommend</p>
          </div>
        </div>
      </div>
    </section>
  );
}
