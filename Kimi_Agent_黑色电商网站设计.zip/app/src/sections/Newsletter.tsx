import { useEffect, useRef, useState } from 'react';
import { Mail, ArrowRight, Check, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export function Newsletter() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setIsLoading(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setIsLoading(false);
    setIsSubmitted(true);
  };

  return (
    <section ref={sectionRef} className="py-20 bg-black border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`relative bg-white/5 rounded-3xl overflow-hidden border border-white/10 ${
            isVisible ? 'animate-fade-in-up' : 'opacity-0'
          }`}
        >
          {/* Decorative Elements */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full blur-2xl translate-y-1/2 -translate-x-1/2" />
          
          {/* Pattern */}
          <div className="absolute inset-0 opacity-20">
            <div className="absolute inset-0" style={{
              backgroundImage: `radial-gradient(circle at 2px 2px, rgba(255, 255, 255, 0.1) 1px, transparent 0)`,
              backgroundSize: '24px 24px'
            }} />
          </div>

          <div className="relative z-10 px-8 py-16 md:px-16 md:py-20">
            <div className="max-w-2xl mx-auto text-center">
              {/* Icon */}
              <div
                className={`inline-flex items-center justify-center w-16 h-16 bg-white rounded-full mb-6 ${
                  isVisible ? 'animate-fade-in-up stagger-1' : 'opacity-0'
                }`}
              >
                <Mail className="w-8 h-8 text-black" />
              </div>

              {/* Content */}
              <h2
                className={`text-3xl sm:text-4xl font-bold text-white mb-4 ${
                  isVisible ? 'animate-fade-in-up stagger-2' : 'opacity-0'
                }`}
              >
                Subscribe to Our Newsletter
              </h2>
              <p
                className={`text-gray-400 mb-8 ${
                  isVisible ? 'animate-fade-in-up stagger-3' : 'opacity-0'
                }`}
              >
                Get the latest deals, new arrivals, and exclusive offers delivered 
                straight to your inbox. Join 50,000+ subscribers today!
              </p>

              {/* Form */}
              {!isSubmitted ? (
                <form
                  onSubmit={handleSubmit}
                  className={`flex flex-col sm:flex-row gap-4 max-w-md mx-auto ${
                    isVisible ? 'animate-fade-in-up stagger-4' : 'opacity-0'
                  }`}
                >
                  <div className="flex-1 relative">
                    <Input
                      type="email"
                      placeholder="Enter your email address"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full h-12 pl-4 pr-4 rounded-full bg-white/10 border-white/20 text-white placeholder:text-gray-500 focus:border-white focus:ring-white"
                      required
                    />
                  </div>
                  <Button
                    type="submit"
                    disabled={isLoading}
                    className="h-12 px-8 rounded-full bg-white text-black hover:bg-gray-200"
                  >
                    {isLoading ? (
                      <span className="flex items-center">
                        <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                        Subscribing...
                      </span>
                    ) : (
                      <span className="flex items-center">
                        Subscribe
                        <ArrowRight className="ml-2 w-4 h-4" />
                      </span>
                    )}
                  </Button>
                </form>
              ) : (
                <div
                  className={`flex flex-col items-center gap-4 animate-scale-in`}
                >
                  <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center">
                    <Check className="w-8 h-8 text-green-500" />
                  </div>
                  <p className="text-lg font-medium text-white">
                    Thank you for subscribing!
                  </p>
                  <p className="text-gray-400">
                    Check your inbox for a welcome email.
                  </p>
                </div>
              )}

              {/* Privacy Note */}
              {!isSubmitted && (
                <p
                  className={`text-xs text-gray-500 mt-4 ${
                    isVisible ? 'animate-fade-in-up stagger-5' : 'opacity-0'
                  }`}
                >
                  We respect your privacy. Unsubscribe at any time.
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
