import { create } from 'zustand';
import type { View } from '@/types';

interface NavigationState {
  currentView: View;
  selectedProductId: string | null;
  setView: (view: View) => void;
  setSelectedProduct: (productId: string | null) => void;
  navigateToProduct: (productId: string) => void;
}

export const useNavigationStore = create<NavigationState>((set) => ({
  currentView: 'home',
  selectedProductId: null,

  setView: (view: View) => set({ currentView: view }),

  setSelectedProduct: (productId: string | null) => set({ selectedProductId: productId }),

  navigateToProduct: (productId: string) =>
    set({ currentView: 'product-detail', selectedProductId: productId }),
}));
