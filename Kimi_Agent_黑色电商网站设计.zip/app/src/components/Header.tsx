import { useState, useEffect } from 'react';
import { Search, ShoppingCart, Menu, X, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { useCartStore } from '@/store/cartStore';
import { useNavigationStore } from '@/store/navigationStore';
import type { View, CartItem } from '@/types';

const navItems: { label: string; view: View }[] = [
  { label: 'Home', view: 'home' },
  { label: 'Shop', view: 'products' },
  { label: 'Categories', view: 'products' },
  { label: 'About', view: 'home' },
  { label: 'Contact', view: 'home' },
];

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  const getTotalItems = useCartStore((state) => state.getTotalItems);
  const { currentView, setView } = useNavigationStore();

  const totalItems = getTotalItems();

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;

      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setIsVisible(false);
      } else {
        setIsVisible(true);
      }

      setIsScrolled(currentScrollY > 50);
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const handleNavClick = (view: View) => {
    setView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (sectionId: string) => {
    if (currentView !== 'home') {
      setView('home');
      setTimeout(() => {
        const element = document.getElementById(sectionId);
        element?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const element = document.getElementById(sectionId);
      element?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-black/95 backdrop-blur-xl border-b border-white/10'
          : 'bg-transparent'
      } ${isVisible ? 'translate-y-0' : '-translate-y-full'}`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center space-x-2 group"
          >
            <span className="text-xl lg:text-2xl font-bold text-white group-hover:text-gray-300 transition-colors">
              LuxeMart
            </span>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            {navItems.map((item) => (
              <button
                key={item.label}
                onClick={() =>
                  item.label === 'Categories'
                    ? scrollToSection('categories')
                    : handleNavClick(item.view)
                }
                className="text-sm font-medium text-gray-300 hover:text-white transition-colors relative group"
              >
                {item.label}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-white transition-all duration-300 group-hover:w-full" />
              </button>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center space-x-2 lg:space-x-4">
            {/* Search */}
            <div className="hidden sm:block relative">
              {isSearchOpen ? (
                <div className="flex items-center">
                  <Input
                    type="text"
                    placeholder="Search products..."
                    className="w-48 lg:w-64 pr-8 animate-fade-in bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                    autoFocus
                    onBlur={() => setIsSearchOpen(false)}
                  />
                  <button
                    onClick={() => setIsSearchOpen(false)}
                    className="absolute right-2 text-gray-400 hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setIsSearchOpen(true)}
                  className="p-2 text-gray-300 hover:text-white transition-colors"
                >
                  <Search className="w-5 h-5" />
                </button>
              )}
            </div>

            {/* Cart */}
            <Sheet>
              <SheetTrigger asChild>
                <button className="relative p-2 text-gray-300 hover:text-white transition-colors">
                  <ShoppingCart className="w-5 h-5" />
                  {totalItems > 0 && (
                    <Badge
                      variant="default"
                      className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center p-0 text-xs bg-white text-black animate-scale-in"
                    >
                      {totalItems}
                    </Badge>
                  )}
                </button>
              </SheetTrigger>
              <SheetContent className="w-full sm:max-w-md bg-black border-white/10">
                <SheetHeader>
                  <SheetTitle className="text-white">Shopping Cart ({totalItems})</SheetTitle>
                </SheetHeader>
                <CartPreview />
              </SheetContent>
            </Sheet>

            {/* User */}
            <button className="hidden sm:block p-2 text-gray-300 hover:text-white transition-colors">
              <User className="w-5 h-5" />
            </button>

            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild>
                <button className="lg:hidden p-2 text-gray-300 hover:text-white transition-colors">
                  <Menu className="w-5 h-5" />
                </button>
              </SheetTrigger>
              <SheetContent side="right" className="w-full sm:max-w-sm bg-black border-white/10">
                <SheetHeader>
                  <SheetTitle className="text-white">Menu</SheetTitle>
                </SheetHeader>
                <nav className="flex flex-col space-y-4 mt-8">
                  {navItems.map((item) => (
                    <button
                      key={item.label}
                      onClick={() => handleNavClick(item.view)}
                      className="text-lg font-medium text-gray-300 hover:text-white transition-colors text-left"
                    >
                      {item.label}
                    </button>
                  ))}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}

function CartPreview() {
  const items = useCartStore((state) => state.items);
  const removeFromCart = useCartStore((state) => state.removeFromCart);
  const updateQuantity = useCartStore((state) => state.updateQuantity);
  const getTotalPrice = useCartStore((state) => state.getTotalPrice);
  const { setView } = useNavigationStore();

  const totalPrice = getTotalPrice();

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-center">
        <ShoppingCart className="w-16 h-16 text-gray-600 mb-4" />
        <p className="text-gray-400">Your cart is empty</p>
        <Button
          className="mt-4 bg-white text-black hover:bg-gray-200"
          onClick={() => setView('products')}
        >
          Start Shopping
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-auto py-4 space-y-4">
        {items.map((item: CartItem) => (
          <div
            key={item.id}
            className="flex items-center space-x-4 p-3 bg-white/5 rounded-lg"
          >
            <img
              src={item.image}
              alt={item.name}
              className="w-16 h-16 object-cover rounded-md"
            />
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-medium text-white truncate">
                {item.name}
              </h4>
              <p className="text-sm text-gray-400 font-semibold">
                ${item.price.toFixed(2)}
              </p>
              <div className="flex items-center space-x-2 mt-1">
                <button
                  onClick={() => updateQuantity(item.id, item.quantity - 1)}
                  className="w-6 h-6 flex items-center justify-center bg-white/10 border border-white/20 rounded hover:bg-white/20 text-white"
                >
                  -
                </button>
                <span className="text-sm text-white">{item.quantity}</span>
                <button
                  onClick={() => updateQuantity(item.id, item.quantity + 1)}
                  className="w-6 h-6 flex items-center justify-center bg-white/10 border border-white/20 rounded hover:bg-white/20 text-white"
                >
                  +
                </button>
              </div>
            </div>
            <button
              onClick={() => removeFromCart(item.id)}
              className="p-1 text-gray-400 hover:text-red-400 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>

      <div className="border-t border-white/10 pt-4 space-y-4">
        <div className="flex justify-between text-lg font-semibold text-white">
          <span>Total</span>
          <span>${totalPrice.toFixed(2)}</span>
        </div>
        <Button
          className="w-full bg-white text-black hover:bg-gray-200"
          onClick={() => setView('cart')}
        >
          View Cart
        </Button>
        <Button
          variant="outline"
          className="w-full border-white/20 text-white hover:bg-white/10"
          onClick={() => setView('checkout')}
        >
          Checkout
        </Button>
      </div>
    </div>
  );
}
