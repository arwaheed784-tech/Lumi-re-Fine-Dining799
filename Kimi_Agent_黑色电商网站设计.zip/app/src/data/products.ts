import type { Product, Category, Testimonial, Review } from '@/types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Wireless Bluetooth Headphones',
    price: 79.99,
    originalPrice: 99.99,
    rating: 4.5,
    reviewCount: 234,
    image: '/images/products/headphones.jpg',
    category: 'electronics',
    description: 'Premium wireless headphones with active noise cancellation, 30-hour battery life, and superior sound quality. Features comfortable over-ear cushions and foldable design for easy portability.',
    features: ['Active Noise Cancellation', '30-hour Battery', 'Bluetooth 5.0', 'Foldable Design'],
    inStock: true,
    isSale: true,
  },
  {
    id: '2',
    name: 'Smart Watch Pro',
    price: 199.99,
    rating: 4.8,
    reviewCount: 189,
    image: '/images/products/smartwatch.jpg',
    category: 'electronics',
    description: 'Advanced smartwatch with health monitoring, GPS tracking, and 7-day battery life. Water-resistant up to 50 meters with customizable watch faces.',
    features: ['Heart Rate Monitor', 'GPS Tracking', '7-day Battery', 'Water Resistant'],
    inStock: true,
    isNew: true,
  },
  {
    id: '3',
    name: 'Minimalist Backpack',
    price: 49.99,
    rating: 4.6,
    reviewCount: 156,
    image: '/images/products/backpack.jpg',
    category: 'fashion',
    description: 'Sleek and functional backpack with laptop compartment, water-resistant material, and ergonomic design. Perfect for daily commute or travel.',
    features: ['Laptop Compartment', 'Water Resistant', 'Ergonomic Straps', 'Multiple Pockets'],
    inStock: true,
  },
  {
    id: '4',
    name: 'Portable Charger 20000mAh',
    price: 39.99,
    rating: 4.4,
    reviewCount: 312,
    image: '/images/products/powerbank.jpg',
    category: 'electronics',
    description: 'High-capacity power bank with fast charging technology. Charge multiple devices simultaneously with dual USB ports and USB-C compatibility.',
    features: ['20000mAh Capacity', 'Fast Charging', 'Dual USB Ports', 'USB-C Compatible'],
    inStock: true,
    isSale: true,
  },
  {
    id: '5',
    name: 'Noise Cancelling Earbuds',
    price: 129.99,
    rating: 4.7,
    reviewCount: 278,
    image: '/images/products/earbuds.jpg',
    category: 'electronics',
    description: 'True wireless earbuds with premium sound quality and active noise cancellation. Touch controls and wireless charging case included.',
    features: ['Active Noise Cancellation', 'Wireless Charging', 'Touch Controls', '24-hour Battery'],
    inStock: true,
    isNew: true,
  },
  {
    id: '6',
    name: 'Leather Wallet',
    price: 34.99,
    rating: 4.3,
    reviewCount: 145,
    image: '/images/products/wallet.jpg',
    category: 'fashion',
    description: 'Genuine leather wallet with RFID blocking technology. Slim design with multiple card slots and bill compartment.',
    features: ['RFID Blocking', 'Genuine Leather', 'Slim Design', '8 Card Slots'],
    inStock: true,
  },
  {
    id: '7',
    name: 'Fitness Tracker',
    price: 89.99,
    rating: 4.5,
    reviewCount: 203,
    image: '/images/products/fitness-tracker.jpg',
    category: 'sports',
    description: 'Comprehensive fitness tracker with heart rate monitoring, sleep tracking, and 14 sports modes. Water-resistant with 10-day battery life.',
    features: ['Heart Rate Monitor', 'Sleep Tracking', '14 Sports Modes', '10-day Battery'],
    inStock: true,
  },
  {
    id: '8',
    name: 'Wireless Mouse',
    price: 29.99,
    rating: 4.2,
    reviewCount: 178,
    image: '/images/products/mouse.jpg',
    category: 'electronics',
    description: 'Ergonomic wireless mouse with precision tracking and silent clicks. Compatible with all major operating systems.',
    features: ['Ergonomic Design', 'Silent Clicks', 'Precision Tracking', '2.4GHz Wireless'],
    inStock: true,
  },
  {
    id: '9',
    name: 'Premium Wireless Headphones',
    price: 149.99,
    rating: 4.9,
    reviewCount: 445,
    image: '/images/products/headphones.jpg',
    category: 'electronics',
    description: 'Studio-quality wireless headphones with premium materials and exceptional sound clarity. Perfect for audiophiles and professionals.',
    features: ['Studio Quality', 'Premium Materials', '40-hour Battery', 'Memory Foam Cushions'],
    inStock: true,
    isNew: true,
  },
  {
    id: '10',
    name: 'Ultra-Slim Laptop Stand',
    price: 59.99,
    rating: 4.6,
    reviewCount: 189,
    image: '/images/products/laptop-stand.jpg',
    category: 'electronics',
    description: 'Adjustable aluminum laptop stand for improved ergonomics. Compatible with laptops up to 17 inches.',
    features: ['Adjustable Height', 'Aluminum Build', 'Portable', 'Heat Dissipation'],
    inStock: true,
  },
  {
    id: '11',
    name: 'Smart Home Hub',
    price: 129.99,
    rating: 4.4,
    reviewCount: 156,
    image: '/images/products/smart-hub.jpg',
    category: 'electronics',
    description: 'Central smart home controller compatible with major protocols. Voice control and automation capabilities.',
    features: ['Voice Control', 'Multi-protocol', 'Automation', 'App Control'],
    inStock: true,
  },
  {
    id: '12',
    name: 'Ergonomic Office Chair',
    price: 299.99,
    rating: 4.7,
    reviewCount: 123,
    image: '/images/products/office-chair.jpg',
    category: 'home',
    description: 'Professional ergonomic office chair with lumbar support and adjustable features. Breathable mesh back for all-day comfort.',
    features: ['Lumbar Support', 'Adjustable Armrests', 'Breathable Mesh', '5-year Warranty'],
    inStock: true,
    isNew: true,
  },
  {
    id: '13',
    name: '4K Webcam Pro',
    price: 89.99,
    rating: 4.5,
    reviewCount: 234,
    image: '/images/products/webcam.jpg',
    category: 'electronics',
    description: 'Professional 4K webcam with auto-focus and noise reduction. Perfect for video conferencing and streaming.',
    features: ['4K Resolution', 'Auto-focus', 'Noise Reduction', 'Wide Angle'],
    inStock: true,
  },
  {
    id: '14',
    name: 'Mechanical Keyboard',
    price: 119.99,
    rating: 4.8,
    reviewCount: 312,
    image: '/images/products/keyboard.jpg',
    category: 'electronics',
    description: 'RGB mechanical keyboard with tactile switches and programmable keys. Durable aluminum construction.',
    features: ['RGB Backlight', 'Tactile Switches', 'Programmable', 'Aluminum Frame'],
    inStock: true,
    isSale: true,
  },
];

export const categories: Category[] = [
  { id: 'electronics', name: 'Electronics', icon: 'Smartphone', productCount: 12 },
  { id: 'fashion', name: 'Fashion', icon: 'ShoppingBag', productCount: 8 },
  { id: 'home', name: 'Home & Living', icon: 'Home', productCount: 6 },
  { id: 'sports', name: 'Sports', icon: 'Dumbbell', productCount: 5 },
  { id: 'beauty', name: 'Beauty', icon: 'Sparkles', productCount: 4 },
  { id: 'books', name: 'Books', icon: 'BookOpen', productCount: 3 },
];

export const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    role: 'Verified Buyer',
    avatar: '/images/avatars/sarah.jpg',
    quote: 'The quality of products exceeded my expectations. Fast shipping and excellent customer service!',
    rating: 5,
  },
  {
    id: '2',
    name: 'Michael Chen',
    role: 'Premium Member',
    avatar: '/images/avatars/michael.jpg',
    quote: "I've been shopping here for months and never been disappointed. Highly recommend to everyone.",
    rating: 5,
  },
  {
    id: '3',
    name: 'Emily Rodriguez',
    role: 'Verified Buyer',
    avatar: '/images/avatars/emily.jpg',
    quote: 'Great prices, amazing selection, and the website is so easy to use. My go-to online store!',
    rating: 5,
  },
];

export const reviews: Review[] = [
  {
    id: '1',
    productId: '1',
    author: 'John Doe',
    avatar: '/images/avatars/sarah.jpg',
    rating: 5,
    date: '2024-01-15',
    comment: 'Amazing sound quality! The noise cancellation works perfectly. Highly recommend!',
  },
  {
    id: '2',
    productId: '1',
    author: 'Jane Smith',
    avatar: '/images/avatars/michael.jpg',
    rating: 4,
    date: '2024-01-10',
    comment: 'Great headphones for the price. Comfortable to wear for long periods.',
  },
  {
    id: '3',
    productId: '2',
    author: 'Mike Johnson',
    avatar: '/images/avatars/emily.jpg',
    rating: 5,
    date: '2024-01-08',
    comment: 'Best smartwatch I have ever owned. Battery life is incredible!',
  },
];

export const getProductById = (id: string): Product | undefined => {
  return products.find((p) => p.id === id);
};

export const getProductsByCategory = (category: string): Product[] => {
  return products.filter((p) => p.category === category);
};

export const getRelatedProducts = (productId: string, limit: number = 4): Product[] => {
  const product = getProductById(productId);
  if (!product) return [];
  return products
    .filter((p) => p.id !== productId && p.category === product.category)
    .slice(0, limit);
};

export const getReviewsByProductId = (productId: string): Review[] => {
  return reviews.filter((r) => r.productId === productId);
};
